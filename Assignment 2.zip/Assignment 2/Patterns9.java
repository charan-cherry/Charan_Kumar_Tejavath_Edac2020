class Patterns9
{
    public static void main(String args[])
    {
            int i,j,k;
            for(i=1; i<=5; i++)
            {
                
                for(j=i; j<=5; j++)
                {
                    System.out.print("*");
            }
                  System.out.println(  );
}
}
    }