

import java.util.Scanner;

public class Patterns13 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Enter number of rows");
        int row= input.nextInt();
        int spacen = row-1;
        int c =1;


        for (int j = 1; j <= spacen; j++)
        {
            System.out.print(" ");
        }
        System.out.println("*");
        spacen--;


        for(int k=1;k<=row-2;k++)
        {
                for (int j = 1; j <= spacen; j++)
                {
                    System.out.print(" ");
                }
                spacen --;

            System.out.print("*");

            for(int l=1;l<=c;l++)
            {
                System.out.print(" ");

            }
            System.out.println("*");
            c=c+2;
        }

        for(int m=1;m<=row;m++)
        {
            System.out.print("* ");
        }
        System.out.println();


    }

}
