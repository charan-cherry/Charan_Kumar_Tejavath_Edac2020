import java.util.Scanner;
class A6
{

public static void main(String args[])
{

int a,b,c,d,e,f,g;
 
Scanner t = new Scanner(System.in);

System.out.println("Enter First Number:");
a=t.nextInt();

System.out.println("Enter Second Number:");
b=t.nextInt();


c=a+b;
d=a-b;
e=a*b;
f=a/b;
g=a%b;


System.out.println("Addition Of Two numbers:"+c);
System.out.println("Subtraction Of Two numbers:"+d);
System.out.println("Multiplication Of Two numbers:"+e);
System.out.println("Dividing Of Two numbers:"+f);
System.out.println("Mod Of Two numbers:"+g);




}


}