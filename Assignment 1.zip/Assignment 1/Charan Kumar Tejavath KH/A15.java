class A15
{
public static void main(String args[])
{

int a,b,m;
a=10;
b=24;
System.out.println("Before swapping a="+a);
System.out.println("Before swapping b="+b);

m=a;
a=b;
b=m;

System.out.println("After swapping a="+a);
System.out.println("After swapping b="+b);



}
}