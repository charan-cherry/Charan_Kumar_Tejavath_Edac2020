import java.util.Scanner;
class A13
{

public static void main(String args[])
{

float a,b,c;
float d;
 
Scanner t = new Scanner(System.in);

System.out.println("Enter Width:");
a=t.nextFloat();

System.out.println("Enter Height:");
b=t.nextFloat();
System.out.println();

c=a*b;

d=2*(a+b);

System.out.println("Area of Rectangle is "+c);
System.out.println();
System.out.println("Perimeter Of Rectangle is "+d);


}

}