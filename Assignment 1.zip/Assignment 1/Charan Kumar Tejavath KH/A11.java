import java.util.Scanner;
class A11
{

public static void main(String args[])
{

double a,b,r;

r=7.5;
 

a=Math.PI*r*r;

b=2*Math.PI*r;


System.out.println("Perimeter of circle is:"+b);
System.out.println();
System.out.println("Area of circle is:"+a);

}


}