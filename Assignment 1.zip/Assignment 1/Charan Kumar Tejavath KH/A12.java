import java.util.Scanner;
class A12
{

public static void main(String args[])
{

double a,b,c;
double d;
 
Scanner t = new Scanner(System.in);

System.out.println("Enter First Number:");
a=t.nextInt();

System.out.println("Enter Second Number:");
b=t.nextInt();

System.out.println("Enter Third Number:");
c=t.nextInt();

System.out.println();

d=(a+b+c)/(3);

System.out.println("Average of Three Numbers:"+d);

}

}