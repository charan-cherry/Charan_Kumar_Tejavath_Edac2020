import java.util.Scanner;
class A5
{

public static void main(String args[])
{

int a,b,c;
 
Scanner t = new Scanner(System.in);

System.out.println("Enter First Number:");
a=t.nextInt();

System.out.println("Enter Second Number:");
b=t.nextInt();


c=a*b;

System.out.println("Multiplication Of Two numbers:"+c);



}


}