
import java.util.Scanner;
class A9
{

public static void main(String args[])
{

double a,b;
 


a= ((25.5 * 3.5 - 3.5 * 3.5) / (40.5 - 4.5));


System.out.println(a);




}


}