import java.util.Scanner;
class A7
{

public static void main(String args[])
{

int a,b;
 
Scanner t = new Scanner(System.in);

System.out.println("Enter a Number:");
a=t.nextInt();
System.out.println();

for(int i=1;i<=10;i++)
{
b=a*i;



System.out.println(b);

}
}

}